import sys

from reloadium.corium import start

start(sys.argv)
