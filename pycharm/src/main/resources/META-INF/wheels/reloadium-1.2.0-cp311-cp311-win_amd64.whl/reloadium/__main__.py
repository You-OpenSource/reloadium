import sys

from reloadium.corium import start

__RELOADIUM__ = True

start(sys.argv)
